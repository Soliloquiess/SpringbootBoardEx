package com.webjjang.board.service;

import com.webjjang.board.vo.BoardVO;

public class BoardUpdateService {

	public int service(BoardVO vo) {
		int result = 0;
		
		// update 처리 -> BoardDAO.update(BoardVO vo)
		
		return result;
	}
	
}
