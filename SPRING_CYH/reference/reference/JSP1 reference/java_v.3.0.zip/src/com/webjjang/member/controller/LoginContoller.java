package com.webjjang.member.controller;

public class LoginContoller {

	public void execute() {
		System.out.println("LoginController.execute");
	}
	
}
