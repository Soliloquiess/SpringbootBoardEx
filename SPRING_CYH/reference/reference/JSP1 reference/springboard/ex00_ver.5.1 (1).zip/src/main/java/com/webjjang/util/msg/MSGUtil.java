package com.webjjang.util.msg;

public class MSGUtil {

	public final static int MSG_LOGIN = 0; 
	public final static int MSG_LOGOUT = 1; 
	public final static int MSG_MEMBER_WRITE = 2; 
	public final static int MSG_MEMBER_PHOTO_UPDATE= 3; 
	public final static int MSG_MEMBER_UPDATE= 4; 
	public final static int MSG_MEMBER_PW_UPDATE= 5; 
	public final static int MSG_MEMBER_DELETE = 6; 
	public final static int MSG_NOTICE_WRITE = 7; 
	public final static int MSG_NOTICE_UPDATE = 8; 
	public final static int MSG_NOTICE_DELETE = 9; 
	public final static int MSG_IMAGE_WRITE = 10; 
	public final static int MSG_IMAGE_FILE_UPDATE= 11; 
	public final static int MSG_IMAGE_UPDATE = 12; 
	public final static int MSG_IMAGE_DELETE = 13; 
	public final static int MSG_BOARD_WRITE = 14; 
	
}
