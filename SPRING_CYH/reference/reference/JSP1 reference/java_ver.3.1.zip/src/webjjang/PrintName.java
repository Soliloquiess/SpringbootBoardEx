package webjjang;

public class PrintName {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// 이름을 출력하는 부분
		System.out.println("이영환");
	}

}
