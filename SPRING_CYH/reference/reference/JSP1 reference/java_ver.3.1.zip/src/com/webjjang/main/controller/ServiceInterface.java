package com.webjjang.main.controller;
/**
 * 서비스들을 실행하기 위한 인터페이스<br>
 * @author EZEN
 *
 */
public interface ServiceInterface {

	public Object service(Object obj) throws Exception;
}
