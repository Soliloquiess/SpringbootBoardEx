package com.webjjang.util.exception;

public class CommonException {

	// 사용법 : CommonException.print(오류메시지, 예외객체)
	public static void print(String msg, Exception e) {
		System.out.println("============[ 모듈 오류 ]==============");
		System.out.println("----------------------------------------------------------------------");
		System.out.println(" + " + msg);
		System.out.println(" + message : " + e.getMessage());
		System.out.println(" + 해결 방법 : 다시 한번 실행보세요.");
		System.out.println("             안되는 경우 전산 담당자 남승진(admin@naver.com)에게 연락주세요.");
		System.out.println("----------------------------------------------------------------------");
	}
	
}
