package com.webjjang.member.service;

import java.util.List;

import com.webjjang.member.dao.MemberDAO;
import com.webjjang.member.vo.MemberVO;

public class MemberListService {

	public List<MemberVO> service() throws Exception{
		MemberDAO dao = new MemberDAO();
		return dao.list();
	}
}
