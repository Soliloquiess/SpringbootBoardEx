package com.webjjang.notice.service;

import com.webjjang.notice.dao.NoticeDAO;
import com.webjjang.notice.vo.NoticeVO;

public class NoticeUpdateService {

	public int service(NoticeVO vo) throws Exception{
		NoticeDAO dao = new NoticeDAO();
		return dao.update(vo);
	}
}
