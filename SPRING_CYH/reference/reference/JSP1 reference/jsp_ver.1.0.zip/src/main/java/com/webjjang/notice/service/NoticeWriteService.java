package com.webjjang.notice.service;

import com.webjjang.notice.dao.NoticeDAO;
import com.webjjang.notice.vo.NoticeVO;

public class NoticeWriteService {

	public int service(NoticeVO vo) throws Exception{
		NoticeDAO dao = new NoticeDAO();
		return dao.write(vo);
	}
}
