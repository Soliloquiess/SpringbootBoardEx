package com.webjjang.image.controller;

public class ImageController {

	// 기본 생성자가 자동으로 생긴다. 컴파일러가 만들어준다.(생성자가 없는 경우만)
	public ImageController() {
		System.out.println("ImageController 생성");
	}
	
	// execute() 선언 -> 타입 메서명(){ 구현 }
	public void execute() {
		System.out.println("ImageController.execute() 실행");
	}
	
}
