package com.webjjang.notice.service;

import java.util.List;

import com.webjjang.notice.dao.NoticeDAO;
import com.webjjang.notice.vo.NoticeVO;

public class NoticeListService {

	public List<NoticeVO> service(String pt) throws Exception{
		NoticeDAO dao = new NoticeDAO();
		return dao.list(pt);
	}
	
}
