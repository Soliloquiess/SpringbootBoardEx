package com.webjjang.grade.service;

import java.util.List;

import com.webjjang.grade.dao.GradeDAO;
import com.webjjang.grade.vo.GradeVO;

public class GradeListService {

	public List<GradeVO> service() throws Exception{
		GradeDAO dao = new GradeDAO();
		return dao.list();
	}
	
}
