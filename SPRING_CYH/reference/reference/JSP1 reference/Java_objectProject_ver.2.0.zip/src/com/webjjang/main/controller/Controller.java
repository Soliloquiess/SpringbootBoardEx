package com.webjjang.main.controller;

public interface Controller {

	public void execute();
	
}
