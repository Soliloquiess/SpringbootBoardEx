-- MySQL dump 10.13  Distrib 8.0.22, for Win64 (x86_64)
--
-- Host: localhost    Database: aloha
-- ------------------------------------------------------
-- Server version	8.0.22

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `board_reply`
--

DROP TABLE IF EXISTS `board_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `board_reply` (
  `reply_no` int NOT NULL AUTO_INCREMENT,
  `writer` varchar(45) COLLATE utf8mb4_bin NOT NULL,
  `content` text COLLATE utf8mb4_bin NOT NULL,
  `board_no` int NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `group_no` int NOT NULL DEFAULT '0',
  `depth_no` int NOT NULL DEFAULT '0',
  `seq_no` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`reply_no`),
  KEY `board_no_fk_idx` (`board_no`),
  CONSTRAINT `board_no_fk` FOREIGN KEY (`board_no`) REFERENCES `board` (`board_no`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `board_reply`
--

LOCK TABLES `board_reply` WRITE;
/*!40000 ALTER TABLE `board_reply` DISABLE KEYS */;
INSERT INTO `board_reply` VALUES (90,'원본','원본',1518,'2021-08-09 14:53:40',90,0,0),(91,'90 답글','90 답글',1518,'2021-08-09 14:53:52',90,1,1),(92,'답글2','답글2',1518,'2021-08-09 14:54:00',90,1,2),(93,'123','123',1518,'2021-08-09 14:58:44',90,1,3),(94,'1234','1234',1518,'2021-08-10 06:37:12',94,0,0),(95,'1234','1234',1518,'2021-08-10 06:42:27',94,1,1),(96,'12341','12344',1518,'2021-08-10 06:45:11',94,1,2),(99,'asdf','asdf',1527,'2021-08-10 06:59:17',99,0,0),(100,'1234','1234',1518,'2021-08-11 11:14:32',100,0,0),(101,'대댓글','대댓글',1518,'2021-08-11 11:15:22',100,1,1),(102,'대대댓글','대대댓글',1518,'2021-08-11 11:17:15',100,1,2),(104,'asdf','asdf',1527,'2021-08-11 11:29:38',104,0,0),(105,'12341','12344',1518,'2021-08-11 11:31:40',94,1,3),(106,'12341','12344',1518,'2021-08-11 11:33:51',94,2,3),(107,'12341','12344',1518,'2021-08-11 11:35:30',100,2,2),(108,'12341','12344',1518,'2021-08-11 11:35:40',100,2,1),(110,'5','6161',1547,'2021-08-23 12:43:45',0,0,0),(119,'fasd','fasd',1521,'2022-05-07 15:01:16',0,0,0),(120,'','',1521,'2022-05-07 15:01:19',0,0,0),(121,'123','4',1547,'2022-05-07 15:51:18',0,0,0),(122,'123','4',1555,'2022-05-07 15:59:59',0,0,0);
/*!40000 ALTER TABLE `board_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-05-08  1:29:01
