package coach.service;

import coach.domain.*;
import coach.mapper.BoardMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired
	private BoardMapper mapper;
	
	@Override
	public void register(Board board) throws Exception {
		mapper.insert(board);
		
		int boardNo = mapper.maxBoardNo();
		board.setGroupNo(boardNo);
		board.setBoardNo(boardNo);
		
		mapper.updateGroupNo(board);
	}

	@Override
	public List<Board> list() throws Exception {
		return mapper.list();
	}

	@Override
	public Board read(Integer boardNo) throws Exception {
		return mapper.read(boardNo);
	}

	@Override
	public void modify(Board board) throws Exception {
		mapper.update(board);
	}

	@Override
	public void remove(Integer boardNo) throws Exception {
		mapper.delete(boardNo);
	}

	@Override
	public List<Board> search(String keyword) throws Exception {
		return mapper.search(keyword);
	}

	@Override
	public Integer totalCount() throws Exception {
		return mapper.totalCount();
	}

	@Override
	public List<Board> list(Page page) throws Exception {
		return mapper.listWithPage(page);
	}

	@Override
	public Integer totalCount(String keyword) throws Exception {
		return mapper.totalCountByKeyword(keyword);
	}

	@Override
	public List<Board> search(Page page) throws Exception {
		return mapper.searchWithPage(page);
	}

	@Override
	public void uploadFile(Attach attach) throws Exception {
		mapper.uploadFile(attach);
	}

	@Override
	public List<Attach> readFileList(Integer boardNo) throws Exception {
		return mapper.readFileList(boardNo);
	}

	@Override
	public void deleteFile(Integer fileNo) throws Exception {
		mapper.deleteFile(fileNo);
	}

	@Override
	public List<Reply> replyList(Integer boardNo) throws Exception {
		return mapper.replyList(boardNo);
	}

	@Override
	public void replyRegister(Reply reply) throws Exception {
		mapper.replyCreate(reply);
		
		int replyNo = mapper.maxReplyNo();
		reply.setGroupNo(replyNo);
		reply.setReplyNo(replyNo);
		
		mapper.replyUpdateGroupNo(reply);
	}

	@Override
	public void replyModify(Reply reply) throws Exception {
		mapper.replyUpdate(reply);
	}

	@Override
	public void replyRemove(Reply reply) throws Exception {
		mapper.deleteReply(reply);
	}

	@Override
	public void answerRegister(Board board) throws Exception {
		
		// 그룹번호
		int groupNo = board.getGroupNo();
		
		// 계층번호
		int depthNo = mapper.readDepthNo(board.getBoardNo());
		board.setDepthNo(depthNo + 1);
		
		// 부모글이 최초 부모글인 경우
		if( board.getSeqNo() == 0 ) {
			// 순서번호 MAX
			int maxSeqNo = mapper.maxSeqNoByGroupNo(groupNo);
			board.setSeqNo(maxSeqNo + 1);
		}
		
		mapper.answerCreate(board);
	}

	@Override
	public void deleteFiles(Integer boardNo) throws Exception {
		mapper.deleteFiles(boardNo);
	}

	@Override
	public Reply replyRead(Reply reply) throws Exception {
		return mapper.replyRead(reply);
	}

	@Override
	public void replyRemoveAll(Reply reply) throws Exception {
		mapper.replyRemoveAll(reply);
	}

	@Override
	public Attach readFile(Attach attach) throws Exception {
		return mapper.readFile(attach);
	}

	@Override
	public int readLikes(Board board) throws Exception {
		return mapper.readLikes(board);
	}

	@Override
	public int readLikesCount(Integer boardNo) throws Exception {
		return mapper.readLikesCount(boardNo);
	}

	@Override
	public int readReplyLikes(Reply reply) throws Exception {
		return mapper.readReplyLikes(reply);
	}

	@Override
	public int readReplyLikesCount(Integer replyNo) throws Exception {
		return mapper.readReplyLikesCount(replyNo);
	}

	@Override
	public void insertLikes(Like like) throws Exception {
		mapper.insertLikes(like);
	}

	@Override
	public void deleteLikes(Board board) throws Exception {
		mapper.deleteLikes(board);
	}

	@Override
	public void replyAnswerRegister(Reply reply) throws Exception {
		
		// 그룹번호
		int groupNo = mapper.replyReadGroupNo( reply.getReplyNo() );	
		reply.setGroupNo(groupNo);
		
		// 계층번호
		int depthNo = mapper.readReplyDepthNo(reply.getReplyNo()) + 1;
		reply.setDepthNo(depthNo);
		
		Reply parent = mapper.replyRead(reply);
		
		// 부모글이 최초 부모글인 경우
		if( parent.getSeqNo() == 0 ) {
			// 순서번호 MAX
			int maxSeqNo = mapper.replyMaxSeqNoByGroupNo(groupNo);
			reply.setSeqNo(maxSeqNo + 1);
		} 
		// 부모글이 답글인 경우
		// 부모글의 순서번호 --> 답글의 순서번호
		else {
			reply.setSeqNo( parent.getSeqNo() );
		}
		
		mapper.replyAnswerCreate(reply);
		
	}

	@Override
	public boolean checkWriter(Integer boardNo, String email) throws Exception {
		String writer = mapper.checkWriter(boardNo, email);

		if( writer.equals(email)) {
			return true;
		} else {
			return false;
		}
	}

}























