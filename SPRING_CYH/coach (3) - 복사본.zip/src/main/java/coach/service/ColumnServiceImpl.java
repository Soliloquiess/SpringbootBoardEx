package coach.service;

import coach.domain.*;
//import coach.mapper.BoardMapper;
import coach.mapper.ColumnMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ColumnServiceImpl implements ColumnService {

	@Autowired
	private ColumnMapper mapper;
	
	@Override
	public void register(Columns columns) throws Exception {
		mapper.insert(columns);
		
		int columnNo = mapper.maxColumnNo();
		columns.setGroupNo(columnNo);
		columns.setColumnNo(columnNo);
		
		mapper.updateGroupNo(columns);
	}

	@Override
	public List<Columns> list() throws Exception {
		return mapper.list();
	}

	@Override
	public Columns read(Integer columnNo) throws Exception {
		return mapper.read(columnNo);
	}

	@Override
	public void modify(Columns columns) throws Exception {
		mapper.update(columns);
	}

	@Override
	public void remove(Integer columnNo) throws Exception {
		mapper.delete(columnNo);
	}

	@Override
	public List<Columns> search(String keyword) throws Exception {
		return mapper.search(keyword);
	}

	@Override
	public Integer totalCount() throws Exception {
		return mapper.totalCount();
	}

	@Override
	public List<Columns> list(Page page) throws Exception {
		return mapper.listWithPage(page);
	}

	@Override
	public Integer totalCount(String keyword) throws Exception {
		return mapper.totalCountByKeyword(keyword);
	}

	@Override
	public List<Columns> search(Page page) throws Exception {
		return mapper.searchWithPage(page);
	}

	@Override
	public void uploadFile(Attach attach) throws Exception {
		mapper.uploadFile(attach);
	}

	@Override
	public List<Attach> readFileList(Integer columnNo) throws Exception {
		return mapper.readFileList(columnNo);
	}

	@Override
	public void deleteFile(Integer fileNo) throws Exception {
		mapper.deleteFile(fileNo);
	}

	@Override
	public List<Reply> replyList(Integer columnNo) throws Exception {
		return mapper.replyList(columnNo);
	}

	@Override
	public void replyRegister(Reply reply) throws Exception {
		mapper.replyCreate(reply);
		
		int replyNo = mapper.maxReplyNo();
		reply.setGroupNo(replyNo);
		reply.setReplyNo(replyNo);
		
		mapper.replyUpdateGroupNo(reply);
	}

	@Override
	public void replyModify(Reply reply) throws Exception {
		mapper.replyUpdate(reply);
	}

	@Override
	public void replyRemove(Reply reply) throws Exception {
		mapper.deleteReply(reply);
	}

	@Override
	public void answerRegister(Columns columns) throws Exception {
		
		// 그룹번호
		int groupNo = columns.getGroupNo();
		
		// 계층번호
		int depthNo = mapper.readDepthNo(columns.getColumnNo());
		columns.setDepthNo(depthNo + 1);
		
		// 부모글이 최초 부모글인 경우
		if( columns.getSeqNo() == 0 ) {
			// 순서번호 MAX
			int maxSeqNo = mapper.maxSeqNoByGroupNo(groupNo);
			columns.setSeqNo(maxSeqNo + 1);
		}
		
		mapper.answerCreate(columns);
	}

	@Override
	public void deleteFiles(Integer columnNo) throws Exception {
		mapper.deleteFiles(columnNo);
	}

	@Override
	public Reply replyRead(Reply reply) throws Exception {
		return mapper.replyRead(reply);
	}

	@Override
	public void replyRemoveAll(Reply reply) throws Exception {
		mapper.replyRemoveAll(reply);
	}

	@Override
	public Attach readFile(Attach attach) throws Exception {
		return mapper.readFile(attach);
	}

	@Override
	public int readLikes(Columns columns) throws Exception {
		return mapper.readLikes(columns);
	}

	@Override
	public int readLikesCount(Integer columnNo) throws Exception {
		return mapper.readLikesCount(columnNo);
	}

	@Override
	public int readReplyLikes(Reply reply) throws Exception {
		return mapper.readReplyLikes(reply);
	}

	@Override
	public int readReplyLikesCount(Integer replyNo) throws Exception {
		return mapper.readReplyLikesCount(replyNo);
	}

	@Override
	public void insertLikes(Like like) throws Exception {
		mapper.insertLikes(like);
	}

	@Override
	public void deleteLikes(Columns columns) throws Exception {
		mapper.deleteLikes(columns);
	}

	@Override
	public void replyAnswerRegister(Reply reply) throws Exception {
		
		// 그룹번호
		int groupNo = mapper.replyReadGroupNo( reply.getReplyNo() );	
		reply.setGroupNo(groupNo);
		
		// 계층번호
		int depthNo = mapper.readReplyDepthNo(reply.getReplyNo()) + 1;
		reply.setDepthNo(depthNo);
		
		Reply parent = mapper.replyRead(reply);
		
		// 부모글이 최초 부모글인 경우
		if( parent.getSeqNo() == 0 ) {
			// 순서번호 MAX
			int maxSeqNo = mapper.replyMaxSeqNoByGroupNo(groupNo);
			reply.setSeqNo(maxSeqNo + 1);
		} 
		// 부모글이 답글인 경우
		// 부모글의 순서번호 --> 답글의 순서번호
		else {
			reply.setSeqNo( parent.getSeqNo() );
		}
		
		mapper.replyAnswerCreate(reply);
		
	}

}























