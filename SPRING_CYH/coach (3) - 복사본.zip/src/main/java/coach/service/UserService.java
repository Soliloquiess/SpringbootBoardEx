package coach.service;

import coach.domain.Users;

public interface UserService {

    public Users read(String email) throws Exception;

    public void insert(Users users) throws Exception;
}
