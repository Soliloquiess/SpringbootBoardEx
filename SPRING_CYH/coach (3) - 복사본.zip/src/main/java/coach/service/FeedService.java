package coach.service;

public interface FeedService {

}
