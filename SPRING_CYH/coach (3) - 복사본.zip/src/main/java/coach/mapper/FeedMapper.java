package coach.mapper;

public interface FeedMapper {

}
