package coach.mapper;

import coach.domain.*;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ColumnMapper {

    // 게시글 쓰기
    public void insert(Columns columns) throws Exception;

    // 게시글 목록
    public List<Columns> list() throws Exception;

    // 게시글 조회
    public Columns read(Integer columnNo) throws Exception;

    // 게시글 수정
    public void update(Columns columns) throws Exception;

    // 게시글 삭제
    public void delete(Integer columnNo) throws Exception;

    // 게시글 검색
    public List<Columns> search(String keyword) throws Exception;

    // 전체 게시글 수
    public Integer totalCount() throws Exception;

    // [페이지] 게시글 목록
    public List<Columns> listWithPage(Page page) throws Exception;

    // [검색어] 게시글 수
    public Integer totalCountByKeyword(String keyword) throws Exception;

    // [페이지][검색어] 게시글 검색
    public List<Columns> searchWithPage(Page page) throws Exception;

    // 파일 업로드
    public void uploadFile(Attach attach) throws Exception;

    // 파일 목록
    public List<Attach> readFileList(Integer columnNo) throws Exception;

    // 파일 삭제
    public void deleteFile(Integer fileNo) throws Exception;

    // 댓글 목록
    public List<Reply> replyList(Integer columnNo) throws Exception;

    // 댓글 등록
    public void replyCreate(Reply reply) throws Exception;

    // 댓글 수정
    public void replyUpdate(Reply reply) throws Exception;

    // 댓글 삭제
    public void deleteReply(Reply reply) throws Exception;

    // 답글 등록
    public void answerCreate(Columns bocolumnard) throws Exception;

    // 계층번호 조회
    public int readDepthNo(Integer columnNo) throws Exception;

    // 같은 그룹번호인, 순서번호 MAX 조회
    public int maxSeqNoByGroupNo(Integer groupNo) throws Exception;

    // max(글번호)
    public int maxColumnNo() throws Exception;

    // 그룹번호 수정
    public void updateGroupNo(Columns columns) throws Exception;

    // 게시글 첨부파일 전체 삭제
    public void deleteFiles(Integer columnNo) throws Exception;


    // 댓글 읽기
    public Reply replyRead(Reply reply) throws Exception;

    // 댓글 전체 삭제 (게시글)
    public void replyRemoveAll(Reply reply) throws Exception;

    // 파일 읽기
    public Attach readFile(Attach attach) throws Exception;


    // 좋아요 여부 조회
    public int readLikes(Columns columns) throws Exception;

    // 좋아요 개수 조회
    public int readLikesCount(Integer columnNo) throws Exception;

    // (댓글) 좋아요 여부 조회
    public int readReplyLikes(Reply reply) throws Exception;

    // (댓글) 좋아요 개수 조회
    public int readReplyLikesCount(Integer replyNo) throws Exception;

    // 좋아요 추가
    public void insertLikes(Like like) throws Exception;

    // 좋아요 취소
    public void deleteLikes(Columns columns) throws Exception;


    // [댓글] 계층번호 조회
    public int readReplyDepthNo(int replyNo) throws Exception;

    // [댓글] 그룹번호 기준 순서번호 최댓값
    public int replyMaxSeqNoByGroupNo(int groupNo) throws Exception;

    // 댓글의 답글 쓰기
    public void replyAnswerCreate(Reply reply) throws Exception;

    // 댓글번호 최댓값 조회
    public int maxReplyNo() throws Exception;

    // [댓글] 그룹번호 수정
    public void replyUpdateGroupNo(Reply reply) throws Exception;

    // [댓글] 그룹번호 조회
    public int replyReadGroupNo(int replyNo) throws Exception;


}


