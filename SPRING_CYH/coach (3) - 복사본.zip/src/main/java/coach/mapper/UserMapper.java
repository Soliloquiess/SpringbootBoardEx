package coach.mapper;

import coach.domain.Users;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {

	public Users read(String email);

    public void insert(Users users) throws Exception;
}
