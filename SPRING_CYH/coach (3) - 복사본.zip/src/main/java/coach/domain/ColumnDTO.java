package coach.domain;

import lombok.Data;

import java.util.List;

@Data
public class ColumnDTO {

	private Columns columns;
	private Page page;
	private List<Columns> columnsList;
	private List<Attach> attachList;
	private List<Reply> replyList;
	private boolean like;
	private int likeCount;

	public ColumnDTO() {

	}

	// 글 목록, 페이지
	public ColumnDTO(List<Columns> columnsList, Page page) {
		this.columnsList = columnsList;
		this.page = page;
	}
	// 글, 파일목록, 댓글목록
	public ColumnDTO(Columns columns, List<Attach> attachList, List<Reply> replyList) {
		this.columns = columns;
		this.attachList = attachList;
		this.replyList = replyList;
	}



}
