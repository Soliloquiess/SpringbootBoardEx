package coach.domain;

import lombok.Data;

@Data
public class UsersAuth {

	private Long id;
	private String auth;
	
}
