package coach.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Reply {

	private int replyNo;
	private int boardNo;
	private int columnNo;
	private int userNo;
	private String content;
	private String writer;
	private Date regDate;
	
	private int groupNo;
	private int depthNo;
	private int seqNo;


}
