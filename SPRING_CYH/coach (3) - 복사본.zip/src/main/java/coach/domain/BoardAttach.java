package coach.domain;

import lombok.Data;

import java.util.Date;

@Data
public class BoardAttach {
	
	private int fileNo;
	private String fullName;
	private String fileName;
	private int boardNo;
	private Date regDate;
	
}
