package coach.domain;

import lombok.Data;

import java.util.Date;

@Data
public class ColumnAttach {
	
	private int fileNo;
	private String fullName;
	private String fileName;
	private int columnNo;
	private Date regDate;
	
}
