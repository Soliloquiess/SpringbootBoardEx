package coach.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Like {

	private int likeNo;
	private int likeType;
	private int typeNo;
	private int userNo;
	private Date regDate;
	
	
}
