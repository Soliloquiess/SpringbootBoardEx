package coach.domain;

import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

import java.util.Date;

@Data
public class Columns {

	private int rowNo;
	private int columnNo;
	private int userNo;
	private int groupNo;			// 그룹번호
	private int depthNo;			// 계층번호
	private int seqNo;				// 순서번호
	
	private String title;
	private String content;
	private String writer;
	private Date regDate;
	private Date updDate;

	private int replyCount;					// 댓글개수


	private MultipartFile[] file;			// 파일정보


}
