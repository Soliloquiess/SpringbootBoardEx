package coach.domain;

import lombok.Data;

import java.util.Date;

@Data
public class Attach {
    private int fileNo;
    private String fullName;
    private String fileName;
    private int boardNo;
    private int columnNo;
    private Date regDate;
}
