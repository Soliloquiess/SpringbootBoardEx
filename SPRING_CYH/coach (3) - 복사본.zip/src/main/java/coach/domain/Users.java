package coach.domain;

import java.time.LocalDateTime;
import java.util.List;

import lombok.Data;

@Data
public class Users {

    private Long id;
    private String email;
    private String nickname;
    private String password;
    private int count;
    private int comment_count;
    private int level;
    private String introduce;
    private int point;
    private int period;
    private int purpose;
    private LocalDateTime createDate;
    // 권한
    private List<UsersAuth> authList;
}