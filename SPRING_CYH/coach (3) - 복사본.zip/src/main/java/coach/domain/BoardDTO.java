package coach.domain;

import lombok.Data;

import java.util.List;

@Data
public class BoardDTO {

	private Board board;
	private Users users;
	private Page page;
	private List<Board> boardList;
	private List<Attach> attachList;
	private List<Reply> replyList;
	private boolean like;
	private int likeCount;
	
	public BoardDTO() {
		
	}
	
	// 글 목록, 페이지
	public BoardDTO(List<Board> boardList, Page page) {
		this.boardList = boardList;
		this.page = page;
	}
	// 글, 파일목록, 댓글목록
	public BoardDTO(Board board, List<Attach> attachList, List<Reply> replyList) {
		this.board = board;
		this.attachList = attachList;
		this.replyList = replyList;
	}



}
