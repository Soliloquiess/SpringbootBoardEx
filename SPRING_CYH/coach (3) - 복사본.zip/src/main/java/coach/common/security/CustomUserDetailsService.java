package coach.common.security;


import coach.common.security.domain.CustomUser;
import coach.domain.Users;
import coach.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class CustomUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserMapper userMapper;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		log.info("Load User By UserName : " + email);

		Users users = userMapper.read(email);

		log.info("queried by users mapper: " + users);

		return users == null ? null : new CustomUser(users);
	} 

}
















