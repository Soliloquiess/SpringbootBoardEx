package coach.controller;

import coach.domain.*;

import coach.service.ColumnService;
import coach.util.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@RestController			// @Controller + @ResponseBody
@RequestMapping("/column")
public class ColumnController {

    private static final Logger log = LoggerFactory.getLogger(ColumnController.class);

    // 업로드 경로
    @Value("${upload.path}")
    private String uploadPath;

    @Autowired
    private ColumnService service;

    // 게시글 목록
    @GetMapping( {"/", ""} )
    public ColumnDTO list(Columns columns, Page page) throws Exception {

        String keyword = page.getKeyword();
        Integer totalCount = null;
        Integer rowsPerPage = null;
        Integer pageCount = null;


        // 조회된 게시글 수
        if( page.getTotalCount() == 0 )
            totalCount = service.totalCount();
        else
            totalCount = page.getTotalCount();

        // 페이지 당 노출 게시글 수
        if( page.getRowsPerPage() == 0 )
            rowsPerPage = 10;
        else
            rowsPerPage = page.getRowsPerPage();

        // 노출 페이지 수
        if( page.getPageCount() == 0 )
            pageCount = 10;
        else
            pageCount = page.getPageCount();


        if( page.getPageNum() == 0 ) {
            page = new Page(1, rowsPerPage, pageCount, totalCount, keyword);
        } else {
            page = new Page(page.getPageNum(), rowsPerPage, pageCount, totalCount, keyword);
        }

        List<Columns> list = null;
        if( keyword == null || keyword == "" ) {
            page.setKeyword("");
            list = service.list(page);

            for (Columns b : list) {
                log.info(b.toString());
            }

        } else {
            page.setKeyword(keyword);
            list = service.search(page);
        }

        ColumnDTO columnDTO = new ColumnDTO(list, page);
        return columnDTO;
    }


    // 게시글 쓰기
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @PostMapping(value = {"/", ""})
    public void register(Columns columns /*, MultipartHttpServletRequest request*/) throws Exception {
//		List<MultipartFile> fileList = request.getFiles("file");

        // [파일 정보]
        MultipartFile[] files = columns.getFile();

        log.info(columns.toString());
        for (MultipartFile file : files) {
            log.info("filename : " + file.getOriginalFilename());
            log.info("contetnType : " + file.getContentType());
            log.info("size : " + file.getSize());
        }

        // 글쓰기 요청
        service.register(columns);

        // 파일업로드 - File
        ArrayList<Attach> attachList = FileUtils.uploadFiles(files, uploadPath);

        // 파일업로드 - DB
        for (Attach attach : attachList) {
            service.uploadFile(attach);
        }

    }

    // 게시글 읽기
    @GetMapping("/{columnNo}")
    public ColumnDTO read(@PathVariable("columnNo") Integer columnNo, Columns columns) throws Exception {

        columns = service.read(columnNo);
        List<Attach> attachList = service.readFileList(columnNo);
        List<Reply> replyList = service.replyList(columnNo);

        columns.setUserNo(100);		// 임시
        boolean like = service.readLikes(columns) > 0 ? true : false;
        int likeCount = service.readLikesCount(columnNo);
        ColumnDTO columnDTO = new ColumnDTO(columns, attachList, replyList);
        columnDTO.setLike(like);
        columnDTO.setLikeCount(likeCount);

        return columnDTO;
    }

    // 게시글 수정
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @PutMapping("/{columnNo}")
    public void modify(@PathVariable("columnNo") Integer columnNo, Columns columns) throws Exception {

        // [파일 정보]
        MultipartFile[] files = columns.getFile();

        // 글수정 요청
        service.modify(columns);

        // 파일업로드 - File
        ArrayList<Attach> attachList = FileUtils.uploadFiles(files, uploadPath);

        // 파일업로드 - DB
        for (Attach attach : attachList) {
            service.uploadFile(attach);
        }

    }

    // 게시글 삭제
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @DeleteMapping("/{columnNo}")
    public void remove(@PathVariable("columnNo") Integer columnNo) throws Exception {
        // 게시글 삭제 요청
        service.remove(columnNo);

        // 게시글에 첨부된 파일목록 조회
        List<Attach> attachList =  service.readFileList(columnNo);

        // 게시글에 첨부한 파일 삭제 - File
        boolean delChk = FileUtils.deleteFiles(attachList);

        // 게시글에 첨부판 파일 삭제 - DB
        if( delChk ) {
            service.deleteFiles(columnNo);
        }

    }


    /* 	댓글 	*/

    // 댓글 목록
    @GetMapping("/{columnNo}/replys")
    public List<Reply> replyList(@PathVariable("columnNo") Integer columnNo) throws Exception {
        List<Reply> replyList = service.replyList(columnNo);
        return replyList;
    }


    // 댓글 쓰기
//    @PreAuthorize("isAuthenticated()")
    @PostMapping("/{columnNo}/replys")
    public void replyWrite(@PathVariable("columnNo") Integer columnNo, Reply reply) throws Exception {
        service.replyRegister(reply);
    }

    // 댓글의 답글 쓰기
//    @PreAuthorize("isAuthenticated()")
    @PostMapping("/{columnNo}/replys/{replyNo}")
    public void replyAnswerWrite(@PathVariable("columnNo") Integer columnNo, @PathVariable("replyNo") Integer replyNo,  Reply reply) throws Exception {
        // 부모 댓글의 댓글번호 - replyNo
        reply.setReplyNo(replyNo);
        service.replyAnswerRegister(reply);
    }


    // 댓글 읽기
    @GetMapping("/{columnNo}/replys/{replyNo}")
    public Reply replyRead(@PathVariable Integer columnNo, @PathVariable Integer replyNo) throws Exception {

        Reply reply = new Reply();
        reply.setColumnNo(columnNo);
        reply.setReplyNo(replyNo);

        reply = service.replyRead(reply);

        return reply;
    }

    // 댓글 수정
//    @PreAuthorize("isAuthenticated()")
    @PutMapping("/{columnNo}/replys/{replyNo}")
    public void replyUpdate(@PathVariable Integer columnNo, @PathVariable Integer replyNo, Reply reply) throws Exception {
        service.replyModify(reply);
    }

    // 댓글 삭제
//    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/{columnNo}/replys/{replyNo}")
    public void replyDelete(@PathVariable Integer columnNo, @PathVariable Integer replyNo, Reply reply) throws Exception {
        reply.setBoardNo(columnNo);
        reply.setReplyNo(replyNo);
        service.replyRemove(reply);
    }

    // 댓글 삭제 (전체)
//    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/{columnNo}/replys")
    public void replysDelete(@PathVariable Integer columnNo, @PathVariable Integer replyNo, Reply reply) throws Exception {
        reply.setBoardNo(columnNo);
        reply.setReplyNo(replyNo);
        service.replyRemoveAll(reply);
    }


    /* 파일 */


    // 파일 목록
    @GetMapping("/{columnNo}/files")
    public List<Attach> fileList(@PathVariable Integer columnNo) throws Exception {
        return service.readFileList(columnNo);
    }

    // 파일 등록
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @PostMapping("/{columnNo}/files")
    public void fileWrite(@PathVariable Integer columnNo, Columns columns) throws Exception {

        // [파일 정보]
        MultipartFile[] files = columns.getFile();

        // 파일업로드 - File
        ArrayList<Attach> attachList = FileUtils.uploadFiles(files, uploadPath);

        // 파일업로드 - DB
        for (Attach attach : attachList) {
            service.uploadFile(attach);
        }

    }


    // 파일 읽기
    @GetMapping("/{columnNo}/files/{fileNo}")
    public Attach fileRead(@PathVariable Integer columnNo, @PathVariable Integer fileNo, Attach attach) throws Exception {
        attach.setColumnNo(columnNo);
        attach.setFileNo(fileNo);
        return service.readFile(attach);
    }


    // 파일 삭제
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @DeleteMapping("/{columnNo}/files/{fileNo}")
    public void fileDelete(@PathVariable Integer columnNo, @PathVariable Integer fileNo, Attach attach) throws Exception {

        attach = service.readFile(attach);
        String fullName = attach.getFullName();

        service.deleteFile(fileNo);
        FileUtils.deleteFile(fullName);
    }

    // 파일 삭제 (전체)
//    @PreAuthorize("hasAnyRole('ADMIN', 'COACH')")
    @DeleteMapping("/{columnNo}/files")
    public void filesDelete(@PathVariable Integer columnNo, @PathVariable Integer fileNo, Attach attach) throws Exception {
        service.deleteFiles(columnNo);
    }


    // 좋아요 여부 조회
    @GetMapping("/{columnNo}/likes")
    public boolean readLikes(Columns columns) throws Exception {
        int like = service.readLikes(columns);
        return like > 0 ? true : false;
    }

    // 좋아요 개수 조회
    @GetMapping("/{columnNo}/likes/counts")
    public boolean readLikesCounts(Integer columnNo) throws Exception {
        int like = service.readLikesCount(columnNo);
        return like > 0 ? true : false;
    }

    // (댓글) 좋아요 여부 조회
    @GetMapping("/replys/{replyNo}/likes")
    public boolean readReplyLikes(Reply reply) throws Exception {
        int like = service.readReplyLikes(reply);
        return like > 0 ? true : false;
    }

    // (댓글) 좋아요 개수 조회
    @GetMapping("/replys/{replyNo}/likes/counts")
    public boolean readReplyLikesCounts(Integer replyNo) throws Exception {
        int like = service.readReplyLikesCount(replyNo);
        return like > 0 ? true : false;
    }

    // 좋아요 추가
//    @PreAuthorize("isAuthenticated()")
    @PostMapping("/{columnNo}/likes")
    public void insertLikes(Like like) throws Exception {

        service.insertLikes(like);
    }

    // 좋아요 취소
//    @PreAuthorize("isAuthenticated()")
    @DeleteMapping("/{columnNo}/likes/{userNo}")
    public void deleteLikes(@PathVariable Integer columnNo, @PathVariable Integer userNo, Columns columns) throws Exception {
        columns.setColumnNo(columnNo);
        columns.setUserNo(userNo);
        service.deleteLikes(columns);
    }
}













