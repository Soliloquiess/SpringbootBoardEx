package coach.controller;

import coach.domain.Users;
import coach.service.UserService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@RestController
public class UserController {

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private UserService service;

    @PostMapping("/join")
    public void join(Users users) throws Exception {

        String inputPassword = users.getPassword();
        users.setPassword( passwordEncoder.encode(inputPassword) );
        service.insert(users);
    }



}
