package aloha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BoardAnswerApplicationTests {

	@Test
	void contextLoads() {
	}

}
