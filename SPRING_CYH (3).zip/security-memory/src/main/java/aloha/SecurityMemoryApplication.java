package aloha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecurityMemoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(SecurityMemoryApplication.class, args);
	}

}
