# Getting Started

### IT 늦공 - 공부기록 
  YouTube 
  - https://www.youtube.com/watch?v=uqfY8v-fzQc&list=PL3036mp45iYyP_Dqz7cHuDN6DQcUiKdlM&index=27

### Reference Documentation

For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/2.6.6/gradle-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/2.6.6/gradle-plugin/reference/html/#build-image)
* [Spring Web](https://docs.spring.io/spring-boot/docs/2.6.6/reference/htmlsingle/#boot-features-developing-web-applications)

### Guides

The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/bookmarks/)

### Additional Links

These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

### DB (Oracle 19c)
    - 시퀀스 생성 
    CREATE SEQUENCE  "SCOTT"."SQ_STUDY_RECORD"  
    MINVALUE 1 MAXVALUE 9999 INCREMENT BY 1
    START WITH 1009 NOCACHE  NOORDER  NOCYCLE  
    NOKEEP  NOSCALE  GLOBAL ;
    

    - 테이블 생성
    CREATE TABLE "SCOTT"."STUDY_RECORD"
    (	"KEY_ID" NUMBER(10,0) DEFAULT "SCOTT_DEV"."SQ_STUDY_RECORD"."NEXTVAL",
    "STUDY_DAY" VARCHAR2(20 BYTE),
    "CONTENTS" VARCHAR2(100 BYTE),
    "REG_DAY" DATE,
    CONSTRAINT "PK_STUDY_RECORD" PRIMARY KEY ("KEY_ID")
    )
    ;

    --------
    -- 시퀀스 생성
    CREATE SEQUENCE  "SCOTT"."SQ_MEMBER"  
    MINVALUE 1 MAXVALUE 9999 INCREMENT BY 1
    START WITH 1 NOCACHE  NOORDER  NOCYCLE  
    NOKEEP  NOSCALE  GLOBAL ;

    -- 테이블 생성 
    CREATE TABLE "SCOTT"."STUDY_MEMBER"
    (	"MEMBER_ID" NUMBER(10,0) DEFAULT "SCOTT"."SQ_MEMBER"."NEXTVAL",
    "LOGIN_ID" VARCHAR2(20 BYTE),
    "PASSWORD" VARCHAR2(100 BYTE),
    "NAME" VARCHAR2(100 BYTE),    
    "ROLE" VARCHAR2(100 BYTE),
    "REG_DAY" DATE,
    CONSTRAINT "PK_STUDY_MEMBER" PRIMARY KEY ("MEMBER_ID")
    )
    ;

